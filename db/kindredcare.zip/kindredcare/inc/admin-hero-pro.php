<?php
/**
 * Admin: KindredCare -> Hero — premium.
 *
 * Same Settings API arrangement as the other section screens, and the same
 * furniture from inc/admin-ui.php.
 *
 * @package KindredCare
 */

declare( strict_types = 1 );

defined( 'ABSPATH' ) || exit;

const KINDREDCARE_HERO_PRO_MENU_SLUG = 'kindredcare-hero-pro';

/**
 * Capability callback for this option group.
 */
function kindredcare_hero_pro_capability(): string {
	return kindredcare_admin_capability();
}

/* Priority 10, required after admin-hero.php: lands directly under Hero. */
add_action( 'admin_menu', 'kindredcare_hero_pro_admin_menu', 10 );
/**
 * Add the screen under the KindredCare menu.
 */
function kindredcare_hero_pro_admin_menu(): void {
	add_submenu_page(
		KINDREDCARE_ADMIN_MENU_SLUG,
		__( 'Hero — premium', 'kindredcare' ),
		__( 'Hero — premium', 'kindredcare' ),
		kindredcare_admin_capability(),
		KINDREDCARE_HERO_PRO_MENU_SLUG,
		'kindredcare_hero_pro_render_page'
	);
}

add_action( 'admin_init', 'kindredcare_hero_pro_register_setting' );
/**
 * Register the section's option with the Settings API.
 */
function kindredcare_hero_pro_register_setting(): void {
	register_setting(
		'kindredcare_hero_pro_group',
		KINDREDCARE_HERO_PRO_OPTION,
		array(
			'type'              => 'array',
			'sanitize_callback' => 'kindredcare_hero_pro_sanitize',
			'default'           => array(),
		)
	);
}

add_filter( 'option_page_capability_kindredcare_hero_pro_group', 'kindredcare_hero_pro_capability' );

/**
 * Sanitise the submitted section content.
 *
 * @param mixed $input Raw $_POST value for the option.
 * @return array<string, mixed> Clean option value.
 */
function kindredcare_hero_pro_sanitize( $input ): array {
	$defaults = kindredcare_hero_pro_defaults();

	if ( ! is_array( $input ) ) {
		return array();
	}

	$clean = array(
		'enabled'         => ! empty( $input['enabled'] ),
		'title'           => sanitize_text_field( $input['title'] ?? '' ),
		'title_accent'    => sanitize_text_field( $input['title_accent'] ?? '' ),
		'primary_label'   => sanitize_text_field( $input['primary_label'] ?? '' ),
		'primary_url'     => esc_url_raw( trim( (string) ( $input['primary_url'] ?? '' ) ) ),
		'secondary_label' => sanitize_text_field( $input['secondary_label'] ?? '' ),
		'secondary_url'   => esc_url_raw( trim( (string) ( $input['secondary_url'] ?? '' ) ) ),
		'slides'          => array(),
		'proof'           => array(),
	);

	// Slides: fixed slots. The bundled `file` is structural and never stored.
	foreach ( array_keys( $defaults['slides'] ) as $index ) {
		$row                       = is_array( $input['slides'][ $index ] ?? null ) ? $input['slides'][ $index ] : array();
		$clean['slides'][ $index ] = array(
			'image'   => absint( $row['image'] ?? 0 ),
			'alt'     => sanitize_text_field( $row['alt'] ?? '' ),
			'enabled' => ! empty( $row['enabled'] ),
		);
	}

	foreach ( array_keys( $defaults['proof'] ) as $index ) {
		$row                       = is_array( $input['proof'][ $index ] ?? null ) ? $input['proof'][ $index ] : array();
		$clean['proof'][ $index ] = array(
			'value' => sanitize_text_field( $row['value'] ?? '' ),
			'label' => sanitize_text_field( $row['label'] ?? '' ),
		);
	}

	// The heading names the section for screen readers, so it cannot be empty.
	if ( '' === trim( $clean['title'] ) ) {
		$clean['title'] = $defaults['title'];
	}

	return $clean;
}

add_action( 'admin_enqueue_scripts', 'kindredcare_hero_pro_admin_assets' );
/**
 * Load the shared panel assets on this screen only.
 *
 * @param string $hook_suffix Current admin page.
 */
function kindredcare_hero_pro_admin_assets( string $hook_suffix ): void {
	if ( 'kindredcare_page_' . KINDREDCARE_HERO_PRO_MENU_SLUG !== $hook_suffix ) {
		return;
	}

	wp_enqueue_media();
	kindredcare_admin_enqueue();
}

/**
 * Print one labelled text input.
 *
 * @param string $id    Field id.
 * @param string $key   Option key.
 * @param string $value Current value.
 * @param string $label Visible label.
 * @param string $hint  Hint under the field, empty for none.
 */
function kindredcare_hero_pro_text_field( string $id, string $key, string $value, string $label, string $hint = '' ): void {
	?>
	<div class="kc-field">
		<label class="kc-field__label" for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?></label>
		<input type="text" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( KINDREDCARE_HERO_PRO_OPTION . $key ); ?>" value="<?php echo esc_attr( $value ); ?>" />
		<?php if ( '' !== $hint ) : ?>
			<p class="kc-field__hint"><?php echo esc_html( $hint ); ?></p>
		<?php endif; ?>
	</div>
	<?php
}

/**
 * Render the admin screen.
 */
function kindredcare_hero_pro_render_page(): void {
	if ( ! current_user_can( kindredcare_admin_capability() ) ) {
		wp_die( esc_html__( 'You do not have permission to edit this section.', 'kindredcare' ) );
	}

	$section = kindredcare_hero_pro();
	$option  = KINDREDCARE_HERO_PRO_OPTION;
	?>
	<div class="wrap kc-admin" data-kc-admin>
		<?php
		kindredcare_admin_masthead(
			__( 'Front page', 'kindredcare' ),
			__( 'Hero — premium', 'kindredcare' ),
			sprintf(
				/* translators: %s: link to the section on the front page. */
				esc_html__( 'The dark panel directly under the first hero. The first hero is unaffected by anything here. %s', 'kindredcare' ),
				'<a href="' . esc_url( home_url( '/#hero-pro' ) ) . '" target="_blank" rel="noopener">' . esc_html__( 'View it on the front page', 'kindredcare' ) . '</a>'
			)
		);
		?>

		<form method="post" action="options.php">
			<?php settings_fields( 'kindredcare_hero_pro_group' ); ?>

			<!-- Headline --------------------------------------------------- -->
			<section class="kc-panel">
				<div class="kc-panel__head">
					<?php kindredcare_admin_icon( 'M4 7V5h16v2M9 20h6M12 5v15' ); ?>
					<div class="kc-panel__titles">
						<h2><?php esc_html_e( 'Headline', 'kindredcare' ); ?></h2>
						<p><?php esc_html_e( 'The professional case, under the personal one.', 'kindredcare' ); ?></p>
					</div>
				</div>
				<div class="kc-panel__body">
					<div class="kc-field">
						<?php kindredcare_admin_toggle( $option . '[enabled]', (bool) $section['enabled'], __( 'Show this section on the front page', 'kindredcare' ) ); ?>
					</div>

					<?php
					kindredcare_hero_pro_text_field( 'kc-hp-title', '[title]', (string) $section['title'], __( 'Heading', 'kindredcare' ), __( 'White, first line. Cannot be empty.', 'kindredcare' ) );
					kindredcare_hero_pro_text_field( 'kc-hp-accent', '[title_accent]', (string) $section['title_accent'], __( 'Heading — gold line', 'kindredcare' ), __( 'Second line, in gold. Leave blank for a one-line heading.', 'kindredcare' ) );
					?>

					<div class="kc-field kc-field--split">
						<div>
							<label class="kc-field__label" for="kc-hp-pl"><?php esc_html_e( 'Button text', 'kindredcare' ); ?></label>
							<input type="text" id="kc-hp-pl" name="<?php echo esc_attr( $option ); ?>[primary_label]" value="<?php echo esc_attr( $section['primary_label'] ); ?>" />
						</div>
						<div>
							<label class="kc-field__label" for="kc-hp-pu"><?php esc_html_e( 'Button link', 'kindredcare' ); ?></label>
							<input type="text" id="kc-hp-pu" name="<?php echo esc_attr( $option ); ?>[primary_url]" value="<?php echo esc_attr( $section['primary_url'] ); ?>" />
						</div>
					</div>

					<div class="kc-field kc-field--split">
						<div>
							<label class="kc-field__label" for="kc-hp-sl"><?php esc_html_e( 'Text link', 'kindredcare' ); ?></label>
							<input type="text" id="kc-hp-sl" name="<?php echo esc_attr( $option ); ?>[secondary_label]" value="<?php echo esc_attr( $section['secondary_label'] ); ?>" />
						</div>
						<div>
							<label class="kc-field__label" for="kc-hp-su"><?php esc_html_e( 'Text link destination', 'kindredcare' ); ?></label>
							<input type="text" id="kc-hp-su" name="<?php echo esc_attr( $option ); ?>[secondary_url]" value="<?php echo esc_attr( $section['secondary_url'] ); ?>" />
							<p class="kc-field__hint"><?php esc_html_e( 'Clearing either half removes that control.', 'kindredcare' ); ?></p>
						</div>
					</div>
				</div>
			</section>

			<!-- Proof row -------------------------------------------------- -->
			<section class="kc-panel">
				<div class="kc-panel__head">
					<?php kindredcare_admin_icon( 'M4 19h16M7 15V9M12 15V5M17 15v-3' ); ?>
					<div class="kc-panel__titles">
						<h2><?php esc_html_e( 'Proof row', 'kindredcare' ); ?></h2>
						<p><?php esc_html_e( 'Three short facts under the buttons.', 'kindredcare' ); ?></p>
					</div>
				</div>
				<div class="kc-panel__body">
					<?php
					kindredcare_admin_note(
						__( 'Only <strong>facts the business can stand behind today</strong>. No review counts, years in business or awards until they exist — leave a value blank to drop that item.', 'kindredcare' )
					);

					foreach ( $section['proof'] as $index => $row ) :
						?>
						<div class="kc-field kc-field--split">
							<div>
								<label class="kc-field__label" for="kc-hp-pv-<?php echo esc_attr( (string) $index ); ?>">
									<?php
									/* translators: %d: item number. */
									echo esc_html( sprintf( __( 'Fact %d — value', 'kindredcare' ), $index + 1 ) );
									?>
								</label>
								<input type="text" id="kc-hp-pv-<?php echo esc_attr( (string) $index ); ?>" name="<?php echo esc_attr( $option . '[proof][' . $index . '][value]' ); ?>" value="<?php echo esc_attr( $row['value'] ); ?>" />
							</div>
							<div>
								<label class="kc-field__label" for="kc-hp-plb-<?php echo esc_attr( (string) $index ); ?>"><?php esc_html_e( 'Label', 'kindredcare' ); ?></label>
								<input type="text" id="kc-hp-plb-<?php echo esc_attr( (string) $index ); ?>" name="<?php echo esc_attr( $option . '[proof][' . $index . '][label]' ); ?>" value="<?php echo esc_attr( $row['label'] ); ?>" />
							</div>
						</div>
					<?php endforeach; ?>
				</div>
			</section>

			<!-- Photograph slider ------------------------------------------- -->
			<section class="kc-panel">
				<div class="kc-panel__head">
					<?php kindredcare_admin_icon( 'M4 5h16v14H4zM4 15l4-4 5 5M14 13l2-2 4 4' ); ?>
					<div class="kc-panel__titles">
						<h2><?php esc_html_e( 'Photograph slider', 'kindredcare' ); ?></h2>
						<p><?php esc_html_e( 'The right-hand half of the band.', 'kindredcare' ); ?></p>
					</div>
				</div>
				<div class="kc-panel__body">
					<?php
					kindredcare_admin_note(
						__( 'Photographs cross-fade every 5.5 seconds and fill the full height of the band, so they are cropped tall on desktop and square on phones — keep faces near the centre. <strong>Two or more</strong> switched on shows the arrows and counter.', 'kindredcare' )
					);

					foreach ( $section['slides'] as $index => $slide ) :
						$base = $option . '[slides][' . $index . ']';
						?>
						<div class="kc-field">
							<span class="kc-field__label">
								<?php
								/* translators: %d: slide number. */
								echo esc_html( sprintf( __( 'Photograph %d', 'kindredcare' ), $index + 1 ) );
								?>
							</span>
							<?php
							kindredcare_admin_toggle( $base . '[enabled]', (bool) $slide['enabled'], __( 'Show this photograph', 'kindredcare' ) );
							kindredcare_admin_media_field( 'kc-hp-slide-' . $index, $base . '[image]', (int) $slide['image'], (string) $slide['file'] );
							?>
							<label class="kc-field__label" for="kc-hp-slide-alt-<?php echo esc_attr( (string) $index ); ?>"><?php esc_html_e( 'Description (alt text)', 'kindredcare' ); ?></label>
							<input type="text" id="kc-hp-slide-alt-<?php echo esc_attr( (string) $index ); ?>" name="<?php echo esc_attr( $base . '[alt]' ); ?>" value="<?php echo esc_attr( $slide['alt'] ); ?>" />
						</div>
					<?php endforeach; ?>
				</div>
			</section>

			<?php kindredcare_admin_savebar( __( 'Save premium hero', 'kindredcare' ) ); ?>
		</form>
	</div>
	<?php
}
